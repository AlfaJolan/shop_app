class NotifySettings:
    TELEGRAM_TOKEN = "8471566365:AAFqk7CHSdd8xXqW0aht-U3nwmSqwLjDR6M"
    TELEGRAM_ADMIN_PASSWORD = "testingApp"  # пароль для подписки
    DB_PATH = "app.db"  # твоя основная база (или store_system.db)


notify_settings = NotifySettings()
